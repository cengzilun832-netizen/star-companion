# Lucky Star Cosmic Collection — No Decorative Stars

The Lucky Star mascot keeps its original five-point body silhouette. All additional five-point stars, star icons, starbursts, cross-shaped sparkles, twinkles, asterisks, and the usual hovering star decorations are excluded.

## 01 — Deep-space exploration

1. Astronaut helmet
2. Lunar rover
3. Ringed-planet swing
4. Black-hole pull
5. UFO beam
6. Icy comet-curve surfing
7. Friendly round alien
8. Spiral-galaxy telescope
9. Space capsule
10. Zero-gravity bubbles

## 02 — Surreal cosmic dreams

1. Nebula cloak
2. Planetary-ring hula hoop
3. Lunar eclipse
4. Aurora cape
5. Meteoroid dome umbrella
6. Cosmic jellyfish
7. Circular wormhole
8. Planet turntables
9. Glowing alien egg
10. Crescent-moon cradle

Both sheets are 1536 × 1024 transparent PNG files.
